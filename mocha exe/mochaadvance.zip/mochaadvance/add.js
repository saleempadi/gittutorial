exports.add = function (i, j) {
	return i + j;
};
exports.mul = function (i, j) {
	return i * j;
};